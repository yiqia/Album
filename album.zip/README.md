# album
一个基于uniapp+node.js+mysql的个人相册小程序

前端使用uniapp，后端接口使用node.js编写，数据库使用mysql

相比之前，这个项目写得比较规范一点，也是学习和练习的作品

