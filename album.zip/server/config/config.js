module.exports={
	"server":"http://api.q05.cc/server/",//服务器地址
	
}